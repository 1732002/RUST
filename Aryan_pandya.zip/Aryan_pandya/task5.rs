fn find_median(arr: &[i32]) -> f64 {
    let len = arr.len();
    if len % 2 == 0 {
        let mid_right = len / 2;
        let mid_left = mid_right - 1;
        (arr[mid_left] + arr[mid_right]) as f64 / 2.0
    } else {
        arr[len / 2] as f64
    }
}

fn main() {
    // Test the function with an example array
    let arr = vec![1, 2, 3, 4, 5];
    println!("Median: {}", find_median(&arr));

    let arr = vec![1, 2, 3, 4, 5, 6];
    println!("Median: {}", find_median(&arr));
}
