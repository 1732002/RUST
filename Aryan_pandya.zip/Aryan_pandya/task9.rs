use std::io;

fn reverse_string(input: &str) -> String {
    input.chars().rev().collect::<String>()
}

fn main() {
    // Prompt the user to enter a string
    println!("Enter a string:");

    // Read the input from the user
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Failed to read line");

    // Remove trailing newline character
    input = input.trim().to_string();

    // Reverse the input string
    let reversed = reverse_string(&input);

    // Print the original and reversed strings
    println!("Original: {}", input);
    println!("Reversed: {}", reversed);
}
