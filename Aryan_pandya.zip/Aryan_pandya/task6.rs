fn longest_common_prefix(strings: &[String]) -> String {
    if strings.is_empty() {
        return String::new();
    }

    let mut prefix = String::new();
    let mut char_index = 0;

    'outer: loop {
        let mut prev_char: Option<char> = None;

        for s in strings {
            if char_index >= s.len() {
                break 'outer;
            }

            let current_char = s.chars().nth(char_index).unwrap();

            if let Some(prev) = prev_char {
                if prev != current_char {
                    break 'outer;
                }
            } else {
                prev_char = Some(current_char);
            }
        }

        if let Some(ch) = prev_char {
            prefix.push(ch);
        } else {
            break 'outer;
        }

        char_index += 1;
    }

    prefix
}

fn main() {
    let strings = vec![
        String::from("flower"),
        String::from("flow"),
        String::from("flight"),
    ];
    println!("Longest common prefix: {}", longest_common_prefix(&strings));
}
