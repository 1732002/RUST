fn shortest_word(input: &str) -> Option<&str> {
    input.split_whitespace().min_by_key(|word| word.len())
}

fn main() {
    // Test the function with an example string
    let input = "The quick brown fox jumps over the lazy dog";
    if let Some(shortest) = shortest_word(input) {
        println!("The shortest word is: {}", shortest);
    } else {
        println!("No words found in the input");
    }
}
