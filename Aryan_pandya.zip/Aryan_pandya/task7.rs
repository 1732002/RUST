fn kth_smallest(arr: &mut [i32], k: usize) -> Option<i32> {
    arr.sort();
    arr.get(k - 1).cloned()
}

fn main() {
    let mut arr = [4, 2, 7, 1, 9, 3];
    let k = 3;

    match kth_smallest(&mut arr, k) {
        Some(smallest) => println!("The {}th smallest element is: {}", k, smallest),
        None => println!("Array is too small!"),
    }
}
