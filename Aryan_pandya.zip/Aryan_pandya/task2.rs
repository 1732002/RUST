// Define a function to find the index of the first occurrence of a number in a sorted array
//by aryan pandya
fn first_occurrence_index(arr: &[i32], target: i32) -> Option<usize> {
    // Start with the entire array
    let mut low = 0; // Index of the first element
    let mut high = arr.len() - 1; // Index of the last element

    // Continue searching until there's nothing left to search
    while low <= high {
        // Find the middle element
        let mid = low + (high - low) / 2;

        // If the middle element is the target
        if arr[mid] == target {
            // Check if it's the first occurrence
            if mid == 0 || arr[mid - 1] != target {
                // If it's the first occurrence, return its index
                return Some(mid);
            } else {
                // If not, continue searching in the left subarray
                high = mid - 1;
            }
        }
        // If the middle element is less than the target, search in the right subarray
        else if arr[mid] < target {
            low = mid + 1;
        }
        // If the middle element is greater than the target, search in the left subarray
        else {
            high = mid - 1;
        }
    }

    // If the target is not found in the array, return None
    None
}

fn main() {
    // Test the function with an example array and target
    let arr = [1, 2, 2, 3, 4, 4, 4, 5, 5, 6];
    let target = 4;
    
    // Call the function and print the result
    match first_occurrence_index(&arr, target) {
        Some(index) => println!("First occurrence of {} is at index {}", target, index),
        None => println!("{} not found in the array", target),
    }
}
